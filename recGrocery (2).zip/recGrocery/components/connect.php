<?php
$db_name = 'mysql:host=localhost;dbname=recdb';
$user_name = 'root';
$user_password = 'admin';
$conn = new PDO($db_name, $user_name, $user_password);
?>